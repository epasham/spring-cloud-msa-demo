﻿using Microsoft.EntityFrameworkCore;
using PacktPubToDoAPI.Models;

namespace PacktPubToDoAPI.Models
{
    public class TodoContext : DbContext
    {
        public TodoContext(DbContextOptions<TodoContext> options)
            : base(options)
        {
        }

        public DbSet<TodoItem> TodoItems { get; set; }

    }
}
