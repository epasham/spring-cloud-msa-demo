Login-AzureRmAccount

New-AzureRmRoleDefinition -InputFile "C:\CustomRoles\PacktCustomRole.json"